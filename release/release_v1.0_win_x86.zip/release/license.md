# LICENSE

All resources are attached in the `assets/` folder. For those who downloaded from the Internet, there is URL information embedded in the metadata, with their licenses as follows respectively.

***

## [Sound Effects License](http://www.soundgator.com/userlicense.php)

Our licensing terms are simple:

You may use the sound effects you download in your films, videos, multimedia projects, presentations, apps, games and just about any other project - but you are not allowed to sell, license, distribute or post online the sound effects on their own, in any form as standalone sound effects (audio, video or data), even if you modify them.

The sound effects meant to be incorporated into your projects. They are not meant to be distributed in any way as sound effects or ringtones - or to be used in sound related apps (such as "funny sounds app"). This should be common sense.

Youtube Users: While you may use our sounds in your videos, you may not post our sounds as "sound effect videos" to any website. An example would be a video titled "mosquito sound effect" that just plays our mosquito sound.

If you have any questions, do not hesitate to contact us at:

contact at soundgator.com

***

## [Back Ground Music License](https://www.bensound.com/licensing)

FREE LICENSE WITH ATTRIBUTION

You can use Bensound's music available under the Free License (with the black download button) in your multimedia project (online videos, websites, animations, etc.) for free as long as you credit Bensound.com. Examples of proper way to credit us: "Music: https://www.bensound.com/royalty-free-music or "Music: « Song Title » from Bensound.com"

You cannot:

- You cannot Claim our music as your own.
- You cannot Register our music in any store/platform.
- You cannot use our music for Audio Podcasts or AudioBooks.
- You cannot make music, song or remix with our music.
- You can use our music for Facebook videos but you cannot register them to the Facebook Rights Manager Service (that will keep other users to use our music).

***

## [Image License](https://unsplash.com/license)

License

Unsplash photos are made to be used freely. Our license reflects that.

- All photos can be downloaded and used for free
Commercial and non-commercial purposes
- No permission needed (though attribution is appreciated!)

What is not permitted 👎
- Photos cannot be sold without significant modification.
- Compiling photos from Unsplash to replicate a similar or competing service.

***

## Other Resources

All icons and interface are designed and made by myself. They will be shared by [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). 

***